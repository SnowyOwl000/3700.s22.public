#include <iostream>
#include <stack.h>

using namespace std;

int main() {
    Stack<int>
        s;
    uint32_t
        n,d;

    cout << "Enter a number: ";
    cin >> n;

    while (n != 0) {
        d = n % 10;
        s.push(d);
        n /= 10;
    }

    while (!s.isEmpty()) {
        d = s.pop();
        cout << d << endl;
    }

    return 0;
}
