//
// Created by bob on 1/31/22.
//

#ifndef _POINT_H
#define _POINT_H

#include "fraction.h"

class Point {
public:
    explicit Point(Fraction _x=Fraction(),Fraction _y=Fraction());
    ~Point() = default;

    Point operator+(Point rhs);
    Point operator-(Point rhs);

    Fraction operator*(Point rhs);
    Point operator*(Fraction rhs);

    Point &operator=(Point rhs);

    bool operator==(Point rhs);
    bool operator!=(Point rhs);

    bool operator<(Point rhs);

    Fraction getX() { return x; }
    Fraction getY() { return y; }

private:
    Fraction
        x,y;
};

std::istream &operator>>(std::istream &is,Point &p);
std::ostream &operator<<(std::ostream &os,Point p);

#endif //_POINT_H
