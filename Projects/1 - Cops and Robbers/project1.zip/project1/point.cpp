//
// Created by bob on 1/31/22.
//

#include "point.h"

Point::Point(Fraction _x,Fraction _y) {

    x = _x;
    y = _y;
}

Point Point::operator+(Point rhs) {
    return Point(x+rhs.x,y+rhs.y);
}

Point Point::operator-(Point rhs) {
    return Point(x-rhs.x,y-rhs.y);
}

Fraction Point::operator*(Point rhs) {
    return x * rhs.y - y * rhs.x;
}

Point Point::operator*(Fraction rhs) {
    return Point(x*rhs,y*rhs);
}

Point &Point::operator=(Point rhs) {

    x = rhs.x;
    y = rhs.y;

    return *this;
}

bool Point::operator==(Point rhs) {
    return x == rhs.x && y == rhs.y;
}

bool Point::operator!=(Point rhs) {
    return x != rhs.x || y != rhs.y;
}

bool Point::operator<(Point rhs) {
    return x < rhs.x || (x == rhs.x && y < rhs.y);
}

std::istream &operator>>(std::istream &is,Point &p) {
    Fraction
        x,y;
    char
        lPar,comma,rPar;

    is >> lPar >> x >> comma >> y >> rPar;

    p = Point(x,y);

    return is;
}

std::ostream &operator<<(std::ostream &os,Point p) {

    os << '(' << p.getX() << " , " << p.getY() << ')';

    return os;
}
