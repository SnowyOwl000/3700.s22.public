#include <iostream>
#include "fraction.h"
#include "point.h"

bool turnsLeft(Point a,Point b,Point c) {
    Point
        r,s;

    r = b - a;
    s = c - a;

    return r * s > 0;
}

bool isInsidePolygon(Point p,Point poly[],int32_t nPoints) {

    for (int32_t i=0;i<nPoints;i++)
        if (!turnsLeft(p,poly[i],poly[(i+1)%nPoints]))
            return false;

    return true;
}

int main() {
    Fraction
        foo;

    return 0;
}
