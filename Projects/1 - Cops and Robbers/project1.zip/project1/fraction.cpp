//
// Created by bob on 1/31/22.
//

#include "fraction.h"

int32_t gcd(int32_t a,int32_t b) {
    int32_t
        r;

    a = (a < 0) ? -a : a;
    b = (b < 0) ? -b : b;

    while (b != 0) {
        r = a % b;
        a = b;
        b = r;
    }

    return a;
}

Fraction::Fraction(int32_t _num,int32_t _den) {

    if (_den < 0) {
        _num = -_num;
        _den = -_den;
    }

    int32_t
        g = gcd(_num,_den);

    num = _num / g;
    den = _den / g;
}

Fraction Fraction::operator+(Fraction rhs) const {
    int32_t
        n,d;

    n = num * rhs.den + den * rhs.num;
    d = den * rhs.den;

    return Fraction(n,d);
}

Fraction Fraction::operator-(Fraction rhs) const {
    int32_t
            n,d;

    n = num * rhs.den - den * rhs.num;
    d = den * rhs.den;

    return Fraction(n,d);
}

Fraction Fraction::operator*(Fraction rhs) const {
    int32_t
        n,d;

    n = num * rhs.num;
    d = den * rhs.den;

    return Fraction(n,d);
}

Fraction Fraction::operator/(Fraction rhs) const {
    int32_t
            n,d;

    n = num * rhs.den;
    d = den * rhs.num;

    return Fraction(n,d);
}

Fraction &Fraction::operator=(Fraction rhs) {

    num = rhs.num;
    den = rhs.den;

    return *this;
}

bool Fraction::operator==(Fraction rhs) const {
    return num * rhs.den == den * rhs.num;
}

bool Fraction::operator!=(Fraction rhs) const {
    return num * rhs.den != den * rhs.num;
}

bool Fraction::operator<(Fraction rhs) const {
    return num * rhs.den < den * rhs.num;
}

bool Fraction::operator>(Fraction rhs) const {
    return num * rhs.den > den * rhs.num;
}

bool Fraction::operator<=(Fraction rhs) const {
    return num * rhs.den <= den * rhs.num;
}

bool Fraction::operator>=(Fraction rhs) const {
    return num * rhs.den >= den * rhs.num;
}

Fraction Fraction::operator+(int32_t rhs) const {
    int32_t
        n,d;

    n = num + den * rhs;
    d = den;

    return Fraction(n,d);
}

Fraction Fraction::operator-(int32_t  rhs) const {
    int32_t
        n,d;

    n = num - den * rhs;
    d = den;

    return Fraction(n,d);
}

Fraction Fraction::operator*(int32_t  rhs) const {
    int32_t
        n,d;

    n = num * rhs;
    d = den;

    return Fraction(n,d);
}

Fraction Fraction::operator/(int32_t  rhs) const {
    int32_t
        n,d;

    n = num;
    d = den * rhs;

    return Fraction(n,d);
}

Fraction &Fraction::operator=(int32_t  rhs) {

    num = rhs;
    den = 1;

    return *this;
}

bool Fraction::operator==(int32_t  rhs) const {
    return num == den * rhs;
}

bool Fraction::operator!=(int32_t  rhs) const {
    return num != den * rhs;
}

bool Fraction::operator<(int32_t  rhs) const {
    return num < den * rhs;
}

bool Fraction::operator>(int32_t  rhs) const {
    return num > den * rhs;
}

bool Fraction::operator<=(int32_t  rhs) const {
    return num <= den * rhs;
}

bool Fraction::operator>=(int32_t  rhs) const {
    return num >= den * rhs;
}

std::istream &operator>>(std::istream &is,Fraction &f) {
    int32_t
        n,d;
    char
        slash;

    is >> n >> slash >> d;

    f = Fraction(n,d);

    return is;
}

std::ostream &operator<<(std::ostream &os,Fraction f) {

    os << f.getNum() << " / " << f.getDen();

    return os;
}
