//
// Created by bob on 1/31/22.
//

#ifndef _FRACTION_H
#define _FRACTION_H

#include <iostream>
#include <cstdint>

class Fraction {
public:
    explicit Fraction(int32_t _num=0,int32_t _den=1);
    ~Fraction() = default;

    Fraction operator+(Fraction rhs) const;
    Fraction operator-(Fraction rhs) const;
    Fraction operator*(Fraction rhs) const;
    Fraction operator/(Fraction rhs) const;
    Fraction &operator=(Fraction rhs);

    bool operator==(Fraction rhs) const;
    bool operator!=(Fraction rhs) const;
    bool operator<(Fraction rhs) const;
    bool operator>(Fraction rhs) const;
    bool operator<=(Fraction rhs) const;
    bool operator>=(Fraction rhs) const;

    Fraction operator+(int32_t rhs) const;
    Fraction operator-(int32_t rhs) const;
    Fraction operator*(int32_t rhs) const;
    Fraction operator/(int32_t rhs) const;
    Fraction &operator=(int32_t rhs);

    bool operator==(int32_t rhs) const;
    bool operator!=(int32_t rhs) const;
    bool operator<(int32_t rhs) const;
    bool operator>(int32_t rhs) const;
    bool operator<=(int32_t rhs) const;
    bool operator>=(int32_t rhs) const;

    int32_t getNum() const { return num; }
    int32_t getDen() const { return den; }

private:
    int32_t
        num,
        den;
};

std::istream &operator>>(std::istream &is,Fraction &f);
std::ostream &operator<<(std::ostream &os,Fraction f);


#endif //_FRACTION_H
